package com.example.re_wear;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReWearApplication {
    public static void main(String[] args) {
        SpringApplication.run(ReWearApplication.class, args);
    }
}
