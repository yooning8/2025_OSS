package com.example.re_wear;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReWearApplicationTests {

    @Test
    void contextLoads() {
    }

}
